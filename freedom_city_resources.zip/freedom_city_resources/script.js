// Global variables
let scene, camera, renderer;
let player, playerControls;
let buildings = [];
let npcs = [];
let clock = new THREE.Clock();
let runTimer = 0;
let isRunning = false;
let normalSpeed = 5;
let runSpeed = 10;
let currentSpeed = normalSpeed;
// Camera control variables
let cameraRotation = 0;
let isSwiping = false;
let lastTouchX = 0;
let touchSensitivity = 0.01;

// Initialize the game
function init() {
    // Create scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB); // Sky blue background

    // Create camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 5, 10);
    camera.lookAt(0, 0, 0);

    // Create renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    document.getElementById('game-world').appendChild(renderer.domElement);

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(100, 100, 100);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 1024;
    directionalLight.shadow.mapSize.height = 1024;
    scene.add(directionalLight);

    // Create ground
    createGround();

    // Create player
    createPlayer();

    // Create buildings
    createBuildings();

    // Create NPCs
    createNPCs();

    // Setup controls
    setupControls();

    // Add event listeners
    window.addEventListener('resize', onWindowResize);

    // Start animation loop
    animate();
}

// Create ground
function createGround() {
    const groundGeometry = new THREE.BoxGeometry(100, 1, 100);
    const groundMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x7CFC00,
        roughness: 0.8,
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.position.y = -0.5;
    ground.receiveShadow = true;
    scene.add(ground);
}

// Create player character
function createPlayer() {
    player = new THREE.Group();
    
    // Head
    const headGeometry = new THREE.BoxGeometry(1, 1, 1);
    const headMaterial = new THREE.MeshStandardMaterial({ color: 0xFFA07A });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 2.5;
    head.castShadow = true;
    player.add(head);
    
    // Body
    const bodyGeometry = new THREE.BoxGeometry(1.5, 2, 0.8);
    const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0x4169E1 });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = 1;
    body.castShadow = true;
    player.add(body);
    
    // Arms
    const armGeometry = new THREE.BoxGeometry(0.5, 1.5, 0.5);
    const armMaterial = new THREE.MeshStandardMaterial({ color: 0x4169E1 });
    
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-1, 1, 0);
    leftArm.castShadow = true;
    player.add(leftArm);
    
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(1, 1, 0);
    rightArm.castShadow = true;
    player.add(rightArm);
    
    // Legs
    const legGeometry = new THREE.BoxGeometry(0.5, 1.5, 0.5);
    const legMaterial = new THREE.MeshStandardMaterial({ color: 0x000080 });
    
    const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
    leftLeg.position.set(-0.5, -0.75, 0);
    leftLeg.castShadow = true;
    player.add(leftLeg);
    
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
    rightLeg.position.set(0.5, -0.75, 0);
    rightLeg.castShadow = true;
    player.add(rightLeg);
    
    // Add player to scene
    player.position.set(0, 0.75, 0);
    scene.add(player);
    
    // Create player controls
    playerControls = {
        moveForward: false,
        moveBackward: false,
        moveLeft: false,
        moveRight: false,
        jump: false,
        isJumping: false,
        velocity: new THREE.Vector3(),
        jumpVelocity: 0,
        jumpHeight: 12,
        gravity: 30
    };
}

// Create buildings
function createBuildings() {
    const buildingColors = [0xA52A2A, 0xD2691E, 0x8B4513, 0xDEB887, 0xCD853F];
    
    // Create several buildings
    for (let i = 0; i < 15; i++) {
        const width = Math.random() * 5 + 3;
        const height = Math.random() * 10 + 5;
        const depth = Math.random() * 5 + 3;
        
        const buildingGeometry = new THREE.BoxGeometry(width, height, depth);
        const buildingMaterial = new THREE.MeshStandardMaterial({ 
            color: buildingColors[Math.floor(Math.random() * buildingColors.length)],
            roughness: 0.8
        });
        
        const building = new THREE.Mesh(buildingGeometry, buildingMaterial);
        building.position.set(
            Math.random() * 80 - 40,
            height / 2,
            Math.random() * 80 - 40
        );
        
        // Avoid placing buildings too close to the player
        if (building.position.distanceTo(player.position) > 10) {
            building.castShadow = true;
            building.receiveShadow = true;
            scene.add(building);
            buildings.push(building);
        }
    }
}

// Create NPCs
function createNPCs() {
    const npcColors = [
        { head: 0xFFD700, body: 0x32CD32 },
        { head: 0x00CED1, body: 0xFF6347 },
        { head: 0xDA70D6, body: 0x4682B4 }
    ];
    
    // Create several NPCs
    for (let i = 0; i < 5; i++) {
        const npc = new THREE.Group();
        const colorScheme = npcColors[Math.floor(Math.random() * npcColors.length)];
        
        // Head
        const headGeometry = new THREE.BoxGeometry(1, 1, 1);
        const headMaterial = new THREE.MeshStandardMaterial({ color: colorScheme.head });
        const head = new THREE.Mesh(headGeometry, headMaterial);
        head.position.y = 2.5;
        head.castShadow = true;
        npc.add(head);
        
        // Body
        const bodyGeometry = new THREE.BoxGeometry(1.5, 2, 0.8);
        const bodyMaterial = new THREE.MeshStandardMaterial({ color: colorScheme.body });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        body.position.y = 1;
        body.castShadow = true;
        npc.add(body);
        
        // Arms
        const armGeometry = new THREE.BoxGeometry(0.5, 1.5, 0.5);
        const armMaterial = new THREE.MeshStandardMaterial({ color: colorScheme.body });
        
        const leftArm = new THREE.Mesh(armGeometry, armMaterial);
        leftArm.position.set(-1, 1, 0);
        leftArm.castShadow = true;
        npc.add(leftArm);
        
        const rightArm = new THREE.Mesh(armGeometry, armMaterial);
        rightArm.position.set(1, 1, 0);
        rightArm.castShadow = true;
        npc.add(rightArm);
        
        // Legs
        const legGeometry = new THREE.BoxGeometry(0.5, 1.5, 0.5);
        const legMaterial = new THREE.MeshStandardMaterial({ color: 0x000080 });
        
        const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
        leftLeg.position.set(-0.5, -0.75, 0);
        leftLeg.castShadow = true;
        npc.add(leftLeg);
        
        const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
        rightLeg.position.set(0.5, -0.75, 0);
        rightLeg.castShadow = true;
        npc.add(rightLeg);
        
        // Add NPC to scene
        npc.position.set(
            Math.random() * 80 - 40,
            0.75,
            Math.random() * 80 - 40
        );
        
        // Ensure NPCs are not placed too close to the player or inside buildings
        let validPosition = false;
        while (!validPosition) {
            npc.position.set(
                Math.random() * 80 - 40,
                0.75,
                Math.random() * 80 - 40
            );
            
            if (npc.position.distanceTo(player.position) > 10) {
                validPosition = true;
                
                // Check if NPC is inside a building
                for (const building of buildings) {
                    const buildingBoundingBox = new THREE.Box3().setFromObject(building);
                    if (buildingBoundingBox.containsPoint(npc.position)) {
                        validPosition = false;
                        break;
                    }
                }
            }
        }
        
        // Add direction and speed properties for movement
        npc.userData = {
            direction: new THREE.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize(),
            speed: Math.random() * 1 + 0.5,
            changeDirectionTime: 0
        };
        
        scene.add(npc);
        npcs.push(npc);
    }
}

// Setup controls
function setupControls() {
    // Create look area in the middle of the screen
    const lookArea = document.createElement('div');
    lookArea.id = 'look-area';
    lookArea.style.position = 'absolute';
    lookArea.style.width = '60%';
    lookArea.style.height = '60%';
    lookArea.style.left = '20%';
    lookArea.style.top = '20%';
    lookArea.style.zIndex = '10';
    document.body.appendChild(lookArea);
    
    // Setup look area touch events
    lookArea.addEventListener('touchstart', (e) => {
        isSwiping = true;
        lastTouchX = e.touches[0].clientX;
        e.preventDefault(); // Prevent default to avoid scrolling
    });
    
    document.addEventListener('touchmove', (e) => {
        if (isSwiping) {
            const touchX = e.touches[0].clientX;
            const deltaX = touchX - lastTouchX;
            
            // Update camera rotation
            cameraRotation -= deltaX * touchSensitivity;
            
            lastTouchX = touchX;
            e.preventDefault(); // Prevent default to avoid scrolling
        }
    });
    
    document.addEventListener('touchend', (e) => {
        if (isSwiping) {
            isSwiping = false;
            e.preventDefault(); // Prevent default to avoid scrolling
        }
    });
    
    // Setup look area mouse events for desktop testing
    lookArea.addEventListener('mousedown', (e) => {
        isSwiping = true;
        lastTouchX = e.clientX;
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (isSwiping) {
            const mouseX = e.clientX;
            const deltaX = mouseX - lastTouchX;
            
            // Update camera rotation
            cameraRotation -= deltaX * touchSensitivity;
            
            lastTouchX = mouseX;
            e.preventDefault();
        }
    });
    
    document.addEventListener('mouseup', () => {
        isSwiping = false;
    });
    
    // Joystick controls
    const joystickBase = document.getElementById('joystick-base');
    const joystickThumb = document.getElementById('joystick-thumb');
    
    let isDragging = false;
    let baseRect = joystickBase.getBoundingClientRect();
    const baseRadius = baseRect.width / 2;
    const thumbRadius = joystickThumb.offsetWidth / 2;
    
    function updateJoystickPosition(clientX, clientY) {
        baseRect = joystickBase.getBoundingClientRect();
        const centerX = baseRect.left + baseRadius;
        const centerY = baseRect.top + baseRadius;
        
        let dx = clientX - centerX;
        let dy = clientY - centerY;
        
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance > baseRadius - thumbRadius) {
            const angle = Math.atan2(dy, dx);
            dx = Math.cos(angle) * (baseRadius - thumbRadius);
            dy = Math.sin(angle) * (baseRadius - thumbRadius);
        }
        
        joystickThumb.style.transform = `translate(${dx}px, ${dy}px)`;
        
        // Update player controls based on joystick position
        const normalizedX = dx / (baseRadius - thumbRadius);
        const normalizedY = dy / (baseRadius - thumbRadius);
        
        playerControls.moveForward = normalizedY < -0.3;
        playerControls.moveBackward = normalizedY > 0.3;
        playerControls.moveLeft = normalizedX < -0.3;
        playerControls.moveRight = normalizedX > 0.3;
    }
    
    function resetJoystick() {
        joystickThumb.style.transform = 'translate(0px, 0px)';
        playerControls.moveForward = false;
        playerControls.moveBackward = false;
        playerControls.moveLeft = false;
        playerControls.moveRight = false;
    }
    
    // Touch events for joystick
    joystickBase.addEventListener('touchstart', (e) => {
        isDragging = true;
        updateJoystickPosition(e.touches[0].clientX, e.touches[0].clientY);
    });
    
    document.addEventListener('touchmove', (e) => {
        if (isDragging) {
            updateJoystickPosition(e.touches[0].clientX, e.touches[0].clientY);
        }
    });
    
    document.addEventListener('touchend', () => {
        isDragging = false;
        resetJoystick();
    });
    
    // Mouse events for joystick
    joystickBase.addEventListener('mousedown', (e) => {
        isDragging = true;
        updateJoystickPosition(e.clientX, e.clientY);
    });
    
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            updateJoystickPosition(e.clientX, e.clientY);
        }
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
        resetJoystick();
    });
    
    // Jump button
    const jumpButton = document.getElementById('jump-button');
    jumpButton.addEventListener('click', () => {
        if (!playerControls.isJumping) {
            playerControls.jump = true;
        }
    });
    
    // Run button
    const runButton = document.getElementById('run-button');
    runButton.addEventListener('click', () => {
        if (!isRunning) {
            isRunning = true;
            currentSpeed = runSpeed;
            runTimer = 15; // 15 seconds of running
            runButton.classList.add('active');
        }
    });
    
    // Keyboard controls
    window.addEventListener('keydown', (e) => {
        switch (e.key) {
            case 'w':
            case 'ArrowUp':
                playerControls.moveForward = true;
                break;
            case 's':
            case 'ArrowDown':
                playerControls.moveBackward = true;
                break;
            case 'a':
            case 'ArrowLeft':
                playerControls.moveLeft = true;
                break;
            case 'd':
            case 'ArrowRight':
                playerControls.moveRight = true;
                break;
            case ' ':
                if (!playerControls.isJumping) {
                    playerControls.jump = true;
                }
                break;
            case 'Shift':
                if (!isRunning) {
                    isRunning = true;
                    currentSpeed = runSpeed;
                    runTimer = 15; // 15 seconds of running
                    runButton.classList.add('active');
                }
                break;
        }
    });
    
    window.addEventListener('keyup', (e) => {
        switch (e.key) {
            case 'w':
            case 'ArrowUp':
                playerControls.moveForward = false;
                break;
            case 's':
            case 'ArrowDown':
                playerControls.moveBackward = false;
                break;
            case 'a':
            case 'ArrowLeft':
                playerControls.moveLeft = false;
                break;
            case 'd':
            case 'ArrowRight':
                playerControls.moveRight = false;
                break;
        }
    });
}

// Window resize handler
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// Animation loop
function animate() {
    requestAnimationFrame(animate);
    const delta = clock.getDelta();
    
    // Update player movement
    updatePlayer(delta);
    
    // Update NPCs
    updateNPCs(delta);
    
    // Update camera position and rotation
    updateCamera();
    
    // Update run timer
    if (isRunning) {
        runTimer -= delta;
        if (runTimer <= 0) {
            isRunning = false;
            currentSpeed = normalSpeed;
            document.getElementById('run-button').classList.remove('active');
        }
    }
    
    renderer.render(scene, camera);
}

// Update camera position and rotation
function updateCamera() {
    // Calculate position offset based on the camera rotation
    const distance = 10;
    const height = 5;
    const offsetX = Math.sin(cameraRotation) * distance;
    const offsetZ = Math.cos(cameraRotation) * distance;
    
    // Update camera position
    camera.position.x = player.position.x - offsetX;
    camera.position.y = player.position.y + height;
    camera.position.z = player.position.z - offsetZ;
    
    // Look at player
    camera.lookAt(player.position);
}

// Update player movement
function updatePlayer(delta) {
    // Apply gravity
    playerControls.velocity.y -= playerControls.gravity * delta;
    
    // Handle jumping
    if (playerControls.jump) {
        playerControls.velocity.y = playerControls.jumpHeight;
        playerControls.jump = false;
        playerControls.isJumping = true;
    }
    
    // Calculate movement direction relative to camera rotation
    const moveDirection = new THREE.Vector3();
    
    if (playerControls.moveForward) {
        moveDirection.x += Math.sin(cameraRotation);
        moveDirection.z += Math.cos(cameraRotation);
    }
    if (playerControls.moveBackward) {
        moveDirection.x -= Math.sin(cameraRotation);
        moveDirection.z -= Math.cos(cameraRotation);
    }
    if (playerControls.moveLeft) {
        moveDirection.x += Math.sin(cameraRotation - Math.PI/2);
        moveDirection.z += Math.cos(cameraRotation - Math.PI/2);
    }
    if (playerControls.moveRight) {
        moveDirection.x += Math.sin(cameraRotation + Math.PI/2);
        moveDirection.z += Math.cos(cameraRotation + Math.PI/2);
    }
    
    // Normalize movement direction
    if (moveDirection.length() > 0) {
        moveDirection.normalize();
        
        // Rotate player to face movement direction
        if (moveDirection.x !== 0 || moveDirection.z !== 0) {
            const angle = Math.atan2(moveDirection.x, moveDirection.z);
            player.rotation.y = angle;
        }
    }
    
    // Apply movement velocity
    playerControls.velocity.x = moveDirection.x * currentSpeed;
    playerControls.velocity.z = moveDirection.z * currentSpeed;
    
    // Update player position
    player.position.x += playerControls.velocity.x * delta;
    player.position.y += playerControls.velocity.y * delta;
    player.position.z += playerControls.velocity.z * delta;
    
    // Collision detection with ground
    if (player.position.y < 0.75) {
        player.position.y = 0.75;
        playerControls.velocity.y = 0;
        playerControls.isJumping = false;
    }
    
    // Simple collision detection with buildings
    for (const building of buildings) {
        const buildingBoundingBox = new THREE.Box3().setFromObject(building);
        const playerBoundingBox = new THREE.Box3().setFromObject(player);
        
        if (buildingBoundingBox.intersectsBox(playerBoundingBox)) {
            // Calculate overlap and push player away
            const buildingCenter = new THREE.Vector3();
            buildingBoundingBox.getCenter(buildingCenter);
            
            const playerCenter = new THREE.Vector3();
            playerBoundingBox.getCenter(playerCenter);
            
            const direction = new THREE.Vector3().subVectors(playerCenter, buildingCenter).normalize();
            
            // Push player away from building
            player.position.x += direction.x * 0.1;
            player.position.z += direction.z * 0.1;
        }
    }
    
    // Keep player within bounds
    const boundary = 50;
    if (player.position.x > boundary) player.position.x = boundary;
    if (player.position.x < -boundary) player.position.x = -boundary;
    if (player.position.z > boundary) player.position.z = boundary;
    if (player.position.z < -boundary) player.position.z = -boundary;
}

// Update NPCs
function updateNPCs(delta) {
    for (const npc of npcs) {
        // Update NPC movement
        npc.userData.changeDirectionTime -= delta;
        
        if (npc.userData.changeDirectionTime <= 0) {
            // Change direction randomly
            npc.userData.direction = new THREE.Vector3(
                Math.random() - 0.5,
                0,
                Math.random() - 0.5
            ).normalize();
            
            npc.userData.changeDirectionTime = Math.random() * 3 + 2; // 2-5 seconds
        }
        
        // Rotate NPC to face movement direction
        if (npc.userData.direction.x !== 0 || npc.userData.direction.z !== 0) {
            const angle = Math.atan2(npc.userData.direction.x, npc.userData.direction.z);
            npc.rotation.y = angle;
        }
        
        // Update NPC position
        npc.position.x += npc.userData.direction.x * npc.userData.speed * delta;
        npc.position.z += npc.userData.direction.z * npc.userData.speed * delta;
        
        // Keep NPC within bounds
        const boundary = 50;
        if (npc.position.x > boundary) {
            npc.position.x = boundary;
            npc.userData.direction.x *= -1;
        }
        if (npc.position.x < -boundary) {
            npc.position.x = -boundary;
            npc.userData.direction.x *= -1;
        }
        if (npc.position.z > boundary) {
            npc.position.z = boundary;
            npc.userData.direction.z *= -1;
        }
        if (npc.position.z < -boundary) {
            npc.position.z = -boundary;
            npc.userData.direction.z *= -1;
        }
        
        // Simple collision detection with buildings
        for (const building of buildings) {
            const buildingBoundingBox = new THREE.Box3().setFromObject(building);
            const npcBoundingBox = new THREE.Box3().setFromObject(npc);
            
            if (buildingBoundingBox.intersectsBox(npcBoundingBox)) {
                // Change direction
                npc.userData.direction.x *= -1;
                npc.userData.direction.z *= -1;
                
                // Move away from building
                npc.position.x += npc.userData.direction.x * 0.5;
                npc.position.z += npc.userData.direction.z * 0.5;
            }
        }
    }
}

// Initialize the game on page load
window.onload = init;
